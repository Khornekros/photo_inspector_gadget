﻿using System.Windows.Controls;

namespace ImageProcessingApp.Controls
{
    public class TiltGrid : Grid
    {
    }
}
